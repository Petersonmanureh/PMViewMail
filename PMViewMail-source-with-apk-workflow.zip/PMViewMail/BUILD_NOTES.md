# Build notes

The project source was generated without an Android SDK installed in the build container, so an APK binary is not included in this package. The Kotlin source was parser-checked for structural syntax errors, but the final Android dependency compilation must be completed in Android Studio/CI where Android SDK 37 is available.

Recommended environment:

- Android Studio Rabbit 1 | 2026.2.1 or newer
- JDK 17+
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Android SDK 37
- Build Tools 36.0.0

After first sync, run the app against a real Hostinger mailbox and verify the exact server folder names exposed by that mailbox. PMView Mail already checks common Hostinger/IMAP folder names such as Sent, Sent Items, Drafts, Spam/Junk and Trash/Deleted Items.
