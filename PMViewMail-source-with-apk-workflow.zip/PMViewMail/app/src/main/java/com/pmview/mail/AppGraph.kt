package com.pmview.mail

import android.content.Context
import com.pmview.mail.data.AppSettings
import com.pmview.mail.data.CredentialVault
import com.pmview.mail.mail.MailRepository

class AppGraph(context: Context) {
    val context: Context = context.applicationContext
    val settings = AppSettings(this.context)
    val vault = CredentialVault(this.context)
    val repository = MailRepository(vault, this.context.contentResolver)
}
