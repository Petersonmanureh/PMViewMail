package com.pmview.mail.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pmview.mail.AppGraph
import com.pmview.mail.data.MailFolder

class MailSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val graph = AppGraph(applicationContext)
        if (!graph.vault.isLoggedIn() || !graph.settings.backgroundNotifications) return Result.success()

        return runCatching {
            val latest = graph.repository.load(MailFolder.INBOX, 15)
            if (latest.isEmpty()) return@runCatching Result.success()

            val newestUid = latest.maxOf { it.uid }
            val previous = graph.settings.lastInboxUid
            if (previous == 0L) {
                graph.settings.lastInboxUid = newestUid
                return@runCatching Result.success()
            }

            latest
                .filter { it.uid > previous }
                .sortedBy { it.uid }
                .takeLast(5)
                .forEach { NotificationHelper.notify(applicationContext, it, graph.settings.notificationPreview) }

            if (newestUid > previous) graph.settings.lastInboxUid = newestUid
            Result.success()
        }.getOrElse { Result.retry() }
    }
}
