package com.pmview.mail.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.pmview.mail.MainActivity
import com.pmview.mail.R
import com.pmview.mail.data.MailSummary

object NotificationHelper {
    const val CHANNEL_ID = "new_mail"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "New email",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications when new Hostinger email arrives"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun notify(context: Context, mail: MailSummary, showPreview: Boolean) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_FOLDER, mail.folder.name)
            putExtra(MainActivity.EXTRA_UID, mail.uid)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            mail.uid.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_mail)
            .setContentTitle(mail.fromName.ifBlank { mail.fromAddress })
            .setContentText(if (showPreview) mail.subject else "New email received")
            .setStyle(
                if (showPreview) NotificationCompat.BigTextStyle().bigText("${mail.subject}\n${mail.preview}")
                else null
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_EMAIL)
            .build()

        runCatching { NotificationManagerCompat.from(context).notify(mail.uid.hashCode(), notification) }
    }
}
