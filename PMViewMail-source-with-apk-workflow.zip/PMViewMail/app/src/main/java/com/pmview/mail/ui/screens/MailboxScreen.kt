package com.pmview.mail.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pmview.mail.data.MailFolder
import com.pmview.mail.data.MailSummary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MailboxScreen(
    accountEmail: String,
    folder: MailFolder,
    messages: List<MailSummary>,
    loading: Boolean,
    error: String?,
    query: String,
    onFolder: (MailFolder) -> Unit,
    onRefresh: () -> Unit,
    onSearch: (String) -> Unit,
    onOpen: (MailSummary) -> Unit,
    onToggleStar: (MailSummary, Boolean) -> Unit,
    onCompose: () -> Unit,
    onSettings: () -> Unit,
    onLogout: () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var searchMode by rememberSaveable { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(310.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                accountEmail.firstOrNull()?.uppercaseChar()?.toString() ?: "M",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("PMView Mail", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text(accountEmail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                MailFolder.entries.forEach { item ->
                    NavigationDrawerItem(
                        label = { Text(item.title) },
                        selected = item == folder,
                        icon = { Icon(folderIcon(item), null) },
                        onClick = {
                            onFolder(item)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    selected = false,
                    icon = { Icon(Icons.Outlined.Settings, null) },
                    onClick = {
                        scope.launch { drawerState.close() }
                        onSettings()
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Logout") },
                    selected = false,
                    icon = { Icon(Icons.Outlined.Logout, null) },
                    onClick = onLogout,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        AnimatedContent(targetState = searchMode, label = "searchTitle") { searching ->
                            if (searching) {
                                TextField(
                                    value = query,
                                    onValueChange = onSearch,
                                    placeholder = { Text("Search mail") },
                                    singleLine = true,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                        unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                Text(folder.title, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (searchMode) {
                                searchMode = false
                                onSearch("")
                            } else scope.launch { drawerState.open() }
                        }) {
                            Icon(if (searchMode) Icons.Default.ArrowBack else Icons.Default.Menu, null)
                        }
                    },
                    actions = {
                        if (!searchMode) {
                            IconButton(onClick = { searchMode = true }) { Icon(Icons.Default.Search, "Search") }
                            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh") }
                        } else if (query.isNotBlank()) {
                            IconButton(onClick = { onSearch("") }) { Icon(Icons.Default.Close, "Clear") }
                        }
                    }
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = onCompose,
                    icon = { Icon(Icons.Default.Edit, null) },
                    text = { Text("Compose") }
                )
            }
        ) { padding ->
            PullToRefreshBox(
                isRefreshing = loading,
                onRefresh = onRefresh,
                modifier = Modifier.padding(padding).fillMaxSize()
            ) {
                when {
                    error != null && messages.isEmpty() -> ErrorState(error, onRefresh)
                    !loading && messages.isEmpty() -> EmptyMailbox(folder)
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(messages, key = { "${it.folder.name}-${it.uid}" }) { mail ->
                            EmailRow(mail, onOpen, onToggleStar)
                            HorizontalDivider(modifier = Modifier.padding(start = 78.dp), thickness = .5.dp)
                        }
                        if (error != null) {
                            item {
                                Text(
                                    error,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmailRow(
    mail: MailSummary,
    onOpen: (MailSummary) -> Unit,
    onToggleStar: (MailSummary, Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen(mail) }
            .animateContentSize()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(46.dp).clip(CircleShape),
            color = if (mail.unread) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = CircleShape
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    mail.fromName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                    fontWeight = FontWeight.Bold,
                    color = if (mail.unread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    mail.fromName.ifBlank { mail.fromAddress },
                    fontWeight = if (mail.unread) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    formatMailDate(mail.receivedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (mail.unread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(3.dp))
            Text(
                mail.subject,
                fontWeight = if (mail.unread) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    mail.preview.ifBlank { "No preview" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                AnimatedVisibility(mail.hasAttachments) {
                    Icon(Icons.Default.AttachFile, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(
                    onClick = { onToggleStar(mail, !mail.starred) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        if (mail.starred) Icons.Default.Star else Icons.Outlined.StarBorder,
                        "Star",
                        tint = if (mail.starred) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ErrorState(error: String, onRefresh: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.CloudOff, null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(14.dp))
            Text(error, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(14.dp))
            OutlinedButton(onClick = onRefresh) { Text("Try again") }
        }
    }
}

@Composable
private fun EmptyMailbox(folder: MailFolder) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.Email, null, modifier = Modifier.size(60.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("${folder.title} is clear", fontWeight = FontWeight.SemiBold)
            Text("Nothing to show right now", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun folderIcon(folder: MailFolder) = when (folder) {
    MailFolder.INBOX -> Icons.Outlined.Inbox
    MailFolder.SENT -> Icons.Outlined.Send
    MailFolder.DRAFTS -> Icons.Outlined.Drafts
    MailFolder.SPAM -> Icons.Outlined.Report
    MailFolder.TRASH -> Icons.Outlined.Delete
}

private fun formatMailDate(epoch: Long): String {
    val date = Date(epoch)
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { time = date }
    val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "h:mm a" else if (now.get(Calendar.YEAR) == then.get(Calendar.YEAR)) "MMM d" else "dd/MM/yy"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(date)
}
