package com.pmview.mail.ui.screens

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmview.mail.data.ComposeDraft
import com.pmview.mail.data.OutgoingAttachment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposeScreen(
    draft: ComposeDraft,
    sending: Boolean,
    status: String?,
    onChange: (ComposeDraft) -> Unit,
    onSend: () -> Unit,
    onBack: () -> Unit
) {
    var advanced by rememberSaveable { mutableStateOf(draft.cc.isNotBlank() || draft.bcc.isNotBlank()) }
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val additions = uris.map { uri ->
            val resolver = context.contentResolver
            var name = "Attachment"
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
            }
            OutgoingAttachment(uri, name, resolver.getType(uri) ?: "application/octet-stream")
        }
        onChange(draft.copy(attachments = (draft.attachments + additions).distinctBy { it.uri }))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New message", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.Close, "Close") } },
                actions = {
                    IconButton(onClick = { launcher.launch(arrayOf("*/*")) }) { Icon(Icons.Default.AttachFile, "Attach") }
                    Button(onClick = onSend, enabled = !sending, modifier = Modifier.padding(end = 8.dp)) {
                        if (sending) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        else {
                            Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Send")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = draft.to,
                onValueChange = { onChange(draft.copy(to = it)) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("To") },
                trailingIcon = {
                    IconButton(onClick = { advanced = !advanced }) {
                        Icon(if (advanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore, "CC/BCC")
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            AnimatedVisibility(advanced) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.cc,
                        onValueChange = { onChange(draft.copy(cc = it)) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Cc") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.bcc,
                        onValueChange = { onChange(draft.copy(bcc = it)) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Bcc") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = draft.subject,
                onValueChange = { onChange(draft.copy(subject = it)) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Subject") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = draft.body,
                onValueChange = { onChange(draft.copy(body = it)) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp),
                label = { Text("Message") },
                shape = RoundedCornerShape(14.dp)
            )

            if (draft.attachments.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("Attachments", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                draft.attachments.forEach { attachment ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AttachFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.fileName, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            IconButton(onClick = {
                                onChange(draft.copy(attachments = draft.attachments.filterNot { it.uri == attachment.uri }))
                            }) { Icon(Icons.Default.Close, "Remove") }
                        }
                    }
                }
            }

            AnimatedVisibility(status != null) {
                Text(
                    status.orEmpty(),
                    color = if (status == "Sent") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(vertical = 10.dp)
                )
            }
        }
    }
}
