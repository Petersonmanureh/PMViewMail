package com.pmview.mail.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FF),
    onPrimaryContainer = Color(0xFF0B2C6B),
    secondary = Color(0xFF0F766E),
    background = Color(0xFFF7F9FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFF0F3F8),
    outline = Color(0xFFCAD1DC)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9AB8FF),
    onPrimary = Color(0xFF0A3478),
    primaryContainer = Color(0xFF143F88),
    onPrimaryContainer = Color(0xFFDCE7FF),
    secondary = Color(0xFF79D8CD),
    background = Color(0xFF0C111B),
    surface = Color(0xFF111827),
    surfaceVariant = Color(0xFF1B2432),
    outline = Color(0xFF536174)
)

@Composable
fun PMViewMailTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colors = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}
