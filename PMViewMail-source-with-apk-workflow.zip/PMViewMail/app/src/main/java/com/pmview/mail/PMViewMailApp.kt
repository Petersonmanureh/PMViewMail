package com.pmview.mail

import android.app.Application
import com.pmview.mail.notifications.NotificationHelper
import com.pmview.mail.notifications.SyncScheduler

class PMViewMailApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
        NotificationHelper.createChannel(this)
        if (graph.vault.isLoggedIn() && graph.settings.backgroundNotifications) {
            SyncScheduler.schedule(this, graph.settings.syncMinutes)
        }
    }
}
