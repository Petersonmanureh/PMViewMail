package com.pmview.mail.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmview.mail.AppGraph
import com.pmview.mail.data.*
import com.pmview.mail.notifications.SyncScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MailViewModel(private val graph: AppGraph) : ViewModel() {
    private val _loggedIn = MutableStateFlow(graph.vault.isLoggedIn())
    val loggedIn: StateFlow<Boolean> = _loggedIn.asStateFlow()

    private val _loginLoading = MutableStateFlow(false)
    val loginLoading: StateFlow<Boolean> = _loginLoading.asStateFlow()
    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _folder = MutableStateFlow(MailFolder.INBOX)
    val folder: StateFlow<MailFolder> = _folder.asStateFlow()
    private val _allMessages = MutableStateFlow<List<MailSummary>>(emptyList())
    private val _messages = MutableStateFlow<List<MailSummary>>(emptyList())
    val messages: StateFlow<List<MailSummary>> = _messages.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _mailError = MutableStateFlow<String?>(null)
    val mailError: StateFlow<String?> = _mailError.asStateFlow()
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _detail = MutableStateFlow<MailDetail?>(null)
    val detail: StateFlow<MailDetail?> = _detail.asStateFlow()
    private val _detailLoading = MutableStateFlow(false)
    val detailLoading: StateFlow<Boolean> = _detailLoading.asStateFlow()

    private val _draft = MutableStateFlow(ComposeDraft())
    val draft: StateFlow<ComposeDraft> = _draft.asStateFlow()
    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()
    private val _sendStatus = MutableStateFlow<String?>(null)
    val sendStatus: StateFlow<String?> = _sendStatus.asStateFlow()

    private val _darkMode = MutableStateFlow(graph.settings.darkMode)
    val darkMode: StateFlow<Boolean> = _darkMode.asStateFlow()
    private val _backgroundNotifications = MutableStateFlow(graph.settings.backgroundNotifications)
    val backgroundNotifications: StateFlow<Boolean> = _backgroundNotifications.asStateFlow()
    private val _notificationPreview = MutableStateFlow(graph.settings.notificationPreview)
    val notificationPreview: StateFlow<Boolean> = _notificationPreview.asStateFlow()
    private val _syncMinutes = MutableStateFlow(graph.settings.syncMinutes)
    val syncMinutes: StateFlow<Long> = _syncMinutes.asStateFlow()

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginError.value = "Enter your email and password"
            return
        }
        viewModelScope.launch {
            _loginLoading.value = true
            _loginError.value = null
            val result = graph.repository.authenticate(email.trim(), password)
            if (result.isSuccess) {
                graph.vault.save(email.trim(), password)
                _loggedIn.value = true
                graph.settings.lastInboxUid = 0L
                if (graph.settings.backgroundNotifications) {
                    SyncScheduler.schedule(graph.context, graph.settings.syncMinutes)
                }
                refresh()
            } else {
                _loginError.value = friendlyError(result.exceptionOrNull())
            }
            _loginLoading.value = false
        }
    }

    fun logout() {
        graph.vault.clear()
        graph.settings.lastInboxUid = 0L
        SyncScheduler.cancel(graph.context)
        _allMessages.value = emptyList()
        _messages.value = emptyList()
        _detail.value = null
        _loggedIn.value = false
    }

    fun selectFolder(folder: MailFolder) {
        _folder.value = folder
        _query.value = ""
        refresh()
    }

    fun refresh() {
        if (!_loggedIn.value) return
        viewModelScope.launch {
            _loading.value = true
            _mailError.value = null
            runCatching { graph.repository.load(_folder.value) }
                .onSuccess { list ->
                    _allMessages.value = list
                    _messages.value = filterMessages(list, _query.value)
                    if (_folder.value == MailFolder.INBOX && list.isNotEmpty()) {
                        val newestUid = list.maxOf { it.uid }
                        if (newestUid > graph.settings.lastInboxUid) graph.settings.lastInboxUid = newestUid
                    }
                }
                .onFailure { _mailError.value = friendlyError(it) }
            _loading.value = false
        }
    }

    fun search(value: String) {
        _query.value = value
        _messages.value = filterMessages(_allMessages.value, value)
    }

    fun openMessage(folder: MailFolder, uid: Long) {
        viewModelScope.launch {
            _detailLoading.value = true
            _detail.value = null
            runCatching { graph.repository.read(folder, uid) }
                .onSuccess { detail ->
                    _detail.value = detail
                    _allMessages.value = _allMessages.value.map {
                        if (it.uid == uid && it.folder == folder) it.copy(unread = false) else it
                    }
                    _messages.value = filterMessages(_allMessages.value, _query.value)
                }
                .onFailure { _mailError.value = friendlyError(it) }
            _detailLoading.value = false
        }
    }

    fun toggleStar(folder: MailFolder, uid: Long, starred: Boolean) {
        viewModelScope.launch {
            _allMessages.value = _allMessages.value.map {
                if (it.uid == uid && it.folder == folder) it.copy(starred = starred) else it
            }
            _messages.value = filterMessages(_allMessages.value, _query.value)
            _detail.value = _detail.value?.takeIf { it.uid == uid && it.folder == folder }?.copy(starred = starred) ?: _detail.value
            runCatching { graph.repository.toggleStar(folder, uid, starred) }
        }
    }

    fun delete(folder: MailFolder, uid: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            runCatching { graph.repository.delete(folder, uid) }
                .onSuccess {
                    _allMessages.value = _allMessages.value.filterNot { it.uid == uid && it.folder == folder }
                    _messages.value = filterMessages(_allMessages.value, _query.value)
                    onDone()
                }
                .onFailure { _mailError.value = friendlyError(it) }
        }
    }

    fun newDraft() { _draft.value = ComposeDraft(); _sendStatus.value = null }

    fun reply(detail: MailDetail) {
        _draft.value = ComposeDraft(
            to = detail.fromAddress,
            subject = if (detail.subject.startsWith("Re:", true)) detail.subject else "Re: ${detail.subject}",
            body = "\n\n--- Original message ---\n${detail.body.take(4000)}"
        )
        _sendStatus.value = null
    }

    fun forward(detail: MailDetail) {
        _draft.value = ComposeDraft(
            subject = if (detail.subject.startsWith("Fwd:", true)) detail.subject else "Fwd: ${detail.subject}",
            body = "\n\n--- Forwarded message ---\nFrom: ${detail.fromName} <${detail.fromAddress}>\n\n${detail.body.take(4000)}"
        )
        _sendStatus.value = null
    }

    fun updateDraft(draft: ComposeDraft) { _draft.value = draft }

    fun send(onSuccess: () -> Unit) {
        if (_draft.value.to.isBlank()) {
            _sendStatus.value = "Add at least one recipient"
            return
        }
        viewModelScope.launch {
            _sending.value = true
            _sendStatus.value = null
            graph.repository.send(_draft.value)
                .onSuccess {
                    _sendStatus.value = "Sent"
                    _draft.value = ComposeDraft()
                    onSuccess()
                }
                .onFailure { _sendStatus.value = friendlyError(it) }
            _sending.value = false
        }
    }

    fun setDarkMode(value: Boolean) {
        graph.settings.darkMode = value
        _darkMode.value = value
    }

    fun setBackgroundNotifications(value: Boolean) {
        graph.settings.backgroundNotifications = value
        _backgroundNotifications.value = value
        if (value) SyncScheduler.schedule(graph.context, _syncMinutes.value) else SyncScheduler.cancel(graph.context)
    }

    fun setNotificationPreview(value: Boolean) {
        graph.settings.notificationPreview = value
        _notificationPreview.value = value
    }

    fun setSyncMinutes(value: Long) {
        graph.settings.syncMinutes = value
        _syncMinutes.value = value
        if (_backgroundNotifications.value) SyncScheduler.schedule(graph.context, value)
    }

    fun accountEmail(): String = graph.vault.load()?.email.orEmpty()



    private fun filterMessages(list: List<MailSummary>, query: String): List<MailSummary> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return list
        return list.filter {
            it.subject.lowercase().contains(q) ||
                it.fromName.lowercase().contains(q) ||
                it.fromAddress.lowercase().contains(q) ||
                it.preview.lowercase().contains(q)
        }
    }

    private fun friendlyError(t: Throwable?): String {
        val raw = t?.message.orEmpty()
        return when {
            raw.contains("AuthenticationFailed", true) || raw.contains("authentication", true) -> "Incorrect email or password"
            raw.contains("UnknownHost", true) -> "Unable to reach Hostinger. Check your internet connection."
            raw.contains("timed out", true) -> "Connection timed out. Please try again."
            raw.isNotBlank() -> raw.take(180)
            else -> "Something went wrong. Please try again."
        }
    }
}
