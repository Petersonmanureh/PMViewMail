package com.pmview.mail.mail

import android.content.ContentResolver
import android.text.Html
import com.pmview.mail.data.*
import com.sun.mail.imap.IMAPFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date
import java.util.Properties
import javax.activation.DataHandler
import javax.mail.*
import javax.mail.Flags.Flag
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.mail.util.ByteArrayDataSource

class MailRepository(
    private val vault: CredentialVault,
    private val contentResolver: ContentResolver
) {
    companion object {
        const val IMAP_HOST = "imap.hostinger.com"
        const val IMAP_PORT = "993"
        const val SMTP_HOST = "smtp.hostinger.com"
        const val SMTP_PORT = "465"
    }

    suspend fun authenticate(email: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val session = Session.getInstance(imapProperties())
            val store = session.getStore("imaps")
            store.connect(IMAP_HOST, email.trim(), password)
            store.close()
        }
    }

    suspend fun load(folderType: MailFolder, limit: Int = 60): List<MailSummary> = withContext(Dispatchers.IO) {
        withStore { store ->
            val folder = openFolder(store, folderType, Folder.READ_WRITE) ?: return@withStore emptyList()
            folder.useFolder {
                val total = messageCount
                if (total <= 0) return@useFolder emptyList()
                val start = (total - limit + 1).coerceAtLeast(1)
                getMessages(start, total)
                    .toList()
                    .asReversed()
                    .mapNotNull { msg -> runCatching { summaryOf(folderType, folder, msg) }.getOrNull() }
            }
        }
    }

    suspend fun search(folderType: MailFolder, query: String): List<MailSummary> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext load(folderType)
        val q = query.trim().lowercase()
        load(folderType, 150).filter {
            it.subject.lowercase().contains(q) ||
                it.fromName.lowercase().contains(q) ||
                it.fromAddress.lowercase().contains(q) ||
                it.preview.lowercase().contains(q)
        }
    }

    suspend fun read(folderType: MailFolder, uid: Long): MailDetail? = withContext(Dispatchers.IO) {
        withStore { store ->
            val folder = openFolder(store, folderType, Folder.READ_WRITE) as? IMAPFolder ?: return@withStore null
            folder.useFolder {
                val message = getMessageByUID(uid) ?: return@useFolder null
                message.setFlag(Flag.SEEN, true)
                detailOf(folderType, message, uid)
            }
        }
    }

    suspend fun toggleStar(folderType: MailFolder, uid: Long, starred: Boolean) = withContext(Dispatchers.IO) {
        withStore { store ->
            val folder = openFolder(store, folderType, Folder.READ_WRITE) as? IMAPFolder ?: return@withStore
            folder.useFolder {
                getMessageByUID(uid)?.setFlag(Flag.FLAGGED, starred)
            }
        }
    }

    suspend fun delete(folderType: MailFolder, uid: Long) = withContext(Dispatchers.IO) {
        withStore { store ->
            val source = openFolder(store, folderType, Folder.READ_WRITE) as? IMAPFolder ?: return@withStore
            source.useFolder {
                val message = getMessageByUID(uid) ?: return@useFolder
                val trash = resolveFolder(store, MailFolder.TRASH)
                if (trash != null && folderType != MailFolder.TRASH) {
                    copyMessages(arrayOf(message), trash)
                }
                message.setFlag(Flag.DELETED, true)
                close(true)
            }
        }
    }

    suspend fun send(draft: ComposeDraft): Result<Unit> = withContext(Dispatchers.IO) {
        val creds = vault.load() ?: return@withContext Result.failure(IllegalStateException("You are signed out"))

        val sentMessage = runCatching {
            sendUsing(draft, creds, port = SMTP_PORT, ssl = true)
        }.recoverCatching {
            // Hostinger recommends port 587 with STARTTLS when 465/SSL has an encryption issue.
            sendUsing(draft, creds, port = "587", ssl = false)
        }.getOrElse { return@withContext Result.failure(it) }

        // SMTP only delivers the message; it does not automatically create an IMAP Sent copy.
        // Save the exact successfully-sent MIME message into the account's Sent folder.
        runCatching { appendToSent(sentMessage, creds) }
            .fold(
                onSuccess = { Result.success(Unit) },
                onFailure = {
                    Result.failure(
                        IllegalStateException(
                            "Message was sent, but the copy could not be saved to Sent: ${it.message.orEmpty()}"
                        )
                    )
                }
            )
    }

    private fun sendUsing(draft: ComposeDraft, creds: MailCredentials, port: String, ssl: Boolean): MimeMessage {
        val props = smtpProperties(port, ssl)
        val session = Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication() = PasswordAuthentication(creds.email, creds.password)
        })

        val message = MimeMessage(session).apply {
            setFrom(InternetAddress(creds.email))
            parseAddresses(draft.to).forEach { addRecipient(Message.RecipientType.TO, it) }
            parseAddresses(draft.cc).forEach { addRecipient(Message.RecipientType.CC, it) }
            parseAddresses(draft.bcc).forEach { addRecipient(Message.RecipientType.BCC, it) }
            subject = draft.subject
            sentDate = Date()
        }

        if (draft.attachments.isEmpty()) {
            message.setText(draft.body, Charsets.UTF_8.name())
        } else {
            val multipart = MimeMultipart()
            multipart.addBodyPart(MimeBodyPart().apply { setText(draft.body, Charsets.UTF_8.name()) })
            draft.attachments.forEach { attachment ->
                val bytes = contentResolver.openInputStream(attachment.uri)?.use { it.readBytes() }
                    ?: error("Unable to read ${attachment.fileName}")
                multipart.addBodyPart(MimeBodyPart().apply {
                    dataHandler = DataHandler(ByteArrayDataSource(bytes, attachment.mimeType))
                    fileName = attachment.fileName
                })
            }
            message.setContent(multipart)
        }
        Transport.send(message)
        return message
    }

    private fun appendToSent(message: MimeMessage, creds: MailCredentials) {
        val store = Session.getInstance(imapProperties()).getStore("imaps")
        store.connect(IMAP_HOST, creds.email, creds.password)
        try {
            var sent = resolveFolder(store, MailFolder.SENT)
            if (sent == null) {
                val candidate = store.getFolder("Sent")
                if (!candidate.exists()) candidate.create(Folder.HOLDS_MESSAGES)
                sent = candidate
            }

            val sentFolder = sent ?: error("Unable to locate or create the Sent folder")
            if (!sentFolder.isOpen) sentFolder.open(Folder.READ_WRITE)
            try {
                val copy = MimeMessage(message).apply {
                    setFlag(Flag.SEEN, true)
                    saveChanges()
                }
                sentFolder.appendMessages(arrayOf(copy))
            } finally {
                if (sentFolder.isOpen) sentFolder.close(false)
            }
        } finally {
            if (store.isConnected) store.close()
        }
    }

    private fun parseAddresses(raw: String): List<InternetAddress> =
        if (raw.isBlank()) emptyList() else InternetAddress.parse(raw.replace(';', ','), false).toList()

    private fun imapProperties() = Properties().apply {
        put("mail.store.protocol", "imaps")
        put("mail.imaps.host", IMAP_HOST)
        put("mail.imaps.port", IMAP_PORT)
        put("mail.imaps.ssl.enable", "true")
        put("mail.imaps.connectiontimeout", "15000")
        put("mail.imaps.timeout", "20000")
        put("mail.imaps.writetimeout", "20000")
    }

    private fun smtpProperties(port: String, ssl: Boolean) = Properties().apply {
        put("mail.smtp.auth", "true")
        put("mail.smtp.host", SMTP_HOST)
        put("mail.smtp.port", port)
        put("mail.smtp.ssl.enable", ssl.toString())
        if (!ssl) {
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.starttls.required", "true")
        }
        put("mail.smtp.connectiontimeout", "15000")
        put("mail.smtp.timeout", "20000")
        put("mail.smtp.writetimeout", "20000")
    }

    private suspend fun <T> withStore(block: suspend (Store) -> T): T {
        val creds = vault.load() ?: error("You are signed out")
        val store = Session.getInstance(imapProperties()).getStore("imaps")
        store.connect(IMAP_HOST, creds.email, creds.password)
        return try { block(store) } finally { if (store.isConnected) store.close() }
    }

    private fun resolveFolder(store: Store, type: MailFolder): Folder? {
        val candidates = when (type) {
            MailFolder.INBOX -> listOf("INBOX")
            MailFolder.SENT -> listOf("Sent", "Sent Items", "INBOX.Sent", "Sent Messages")
            MailFolder.DRAFTS -> listOf("Drafts", "INBOX.Drafts")
            MailFolder.SPAM -> listOf("Spam", "Junk", "Junk Email", "INBOX.Spam")
            MailFolder.TRASH -> listOf("Trash", "Deleted Items", "INBOX.Trash")
        }
        val direct = candidates.asSequence()
            .map { store.getFolder(it) }
            .firstOrNull { runCatching { it.exists() }.getOrDefault(false) }
        if (direct != null) return direct

        val aliases = when (type) {
            MailFolder.INBOX -> setOf("inbox")
            MailFolder.SENT -> setOf("sent", "sent items", "sent messages", "sent mail")
            MailFolder.DRAFTS -> setOf("drafts", "draft")
            MailFolder.SPAM -> setOf("spam", "junk", "junk email")
            MailFolder.TRASH -> setOf("trash", "deleted items", "deleted messages")
        }
        val discovered = runCatching { store.defaultFolder.list("*").toList() }.getOrDefault(emptyList())
        val matched = discovered.firstOrNull { folder ->
            val name = folder.name.lowercase()
            val full = folder.fullName.lowercase()
            aliases.any { alias ->
                name == alias || full == alias || full.endsWith(".$alias") || full.endsWith("/$alias")
            }
        }
        return matched ?: if (type == MailFolder.INBOX) store.getFolder("INBOX") else null
    }

    private fun openFolder(store: Store, type: MailFolder, mode: Int): Folder? {
        val folder = resolveFolder(store, type) ?: return null
        folder.open(mode)
        return folder
    }

    private inline fun <F : Folder, T> F.useFolder(block: F.() -> T): T {
        return try { block() } finally { if (isOpen) close(false) }
    }

    private fun summaryOf(type: MailFolder, folder: Folder, message: Message): MailSummary {
        val uid = (folder as? UIDFolder)?.getUID(message) ?: message.messageNumber.toLong()
        val sender = (message.from?.firstOrNull() as? InternetAddress)
        val text = extractText(message).replace(Regex("\\s+"), " ").trim()
        return MailSummary(
            uid = uid,
            folder = type,
            fromName = sender?.personal?.takeIf { it.isNotBlank() } ?: sender?.address.orEmpty().ifBlank { "Unknown" },
            fromAddress = sender?.address.orEmpty(),
            subject = message.subject?.takeIf { it.isNotBlank() } ?: "(No subject)",
            preview = text.take(140),
            receivedAt = (message.receivedDate ?: message.sentDate ?: Date()).time,
            unread = !message.isSet(Flag.SEEN),
            starred = message.isSet(Flag.FLAGGED),
            hasAttachments = hasAttachments(message)
        )
    }

    private fun detailOf(type: MailFolder, message: Message, uid: Long): MailDetail {
        val sender = (message.from?.firstOrNull() as? InternetAddress)
        return MailDetail(
            uid = uid,
            folder = type,
            fromName = sender?.personal?.takeIf { it.isNotBlank() } ?: sender?.address.orEmpty().ifBlank { "Unknown" },
            fromAddress = sender?.address.orEmpty(),
            to = addresses(message, Message.RecipientType.TO),
            cc = addresses(message, Message.RecipientType.CC),
            subject = message.subject?.takeIf { it.isNotBlank() } ?: "(No subject)",
            body = extractText(message).trim(),
            receivedAt = (message.receivedDate ?: message.sentDate ?: Date()).time,
            unread = !message.isSet(Flag.SEEN),
            starred = message.isSet(Flag.FLAGGED),
            attachments = attachmentInfo(message)
        )
    }

    private fun addresses(message: Message, type: Message.RecipientType): List<String> =
        message.getRecipients(type)?.map { it.toString() }.orEmpty()

    private fun extractText(part: Part): String {
        return when {
            part.isMimeType("text/plain") -> part.content?.toString().orEmpty()
            part.isMimeType("text/html") -> Html.fromHtml(part.content?.toString().orEmpty(), Html.FROM_HTML_MODE_LEGACY).toString()
            part.isMimeType("multipart/*") -> {
                val mp = part.content as Multipart
                val plain = buildString {
                    for (i in 0 until mp.count) {
                        val bp = mp.getBodyPart(i)
                        if (bp.disposition?.equals(Part.ATTACHMENT, true) == true) continue
                        if (bp.isMimeType("text/plain")) append(extractText(bp)).append('\n')
                    }
                }.trim()
                if (plain.isNotBlank()) plain else buildString {
                    for (i in 0 until mp.count) {
                        val bp = mp.getBodyPart(i)
                        if (bp.disposition?.equals(Part.ATTACHMENT, true) == true) continue
                        append(extractText(bp)).append('\n')
                    }
                }
            }
            else -> ""
        }
    }

    private fun hasAttachments(part: Part): Boolean = attachmentInfo(part).isNotEmpty()

    private fun attachmentInfo(part: Part): List<AttachmentInfo> {
        if (!part.isMimeType("multipart/*")) return emptyList()
        val result = mutableListOf<AttachmentInfo>()
        val multipart = part.content as Multipart
        for (i in 0 until multipart.count) {
            val bp = multipart.getBodyPart(i)
            if (bp.isMimeType("multipart/*")) {
                result += attachmentInfo(bp)
            } else {
                val filename = bp.fileName
                val disposition = bp.disposition
                if (!filename.isNullOrBlank() || disposition.equals(Part.ATTACHMENT, true)) {
                    result += AttachmentInfo(filename ?: "Attachment", bp.contentType.substringBefore(';'), bp.size)
                }
            }
        }
        return result
    }
}
