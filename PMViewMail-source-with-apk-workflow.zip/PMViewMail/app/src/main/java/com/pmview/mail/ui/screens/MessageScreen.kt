package com.pmview.mail.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmview.mail.data.MailDetail
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageScreen(
    detail: MailDetail?,
    loading: Boolean,
    onBack: () -> Unit,
    onStar: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onReply: () -> Unit,
    onForward: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Message") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                },
                actions = {
                    detail?.let {
                        IconButton(onClick = { onStar(!it.starred) }) {
                            Icon(
                                if (it.starred) Icons.Default.Star else Icons.Outlined.StarBorder,
                                "Star",
                                tint = if (it.starred) MaterialTheme.colorScheme.primary else LocalContentColor.current
                            )
                        }
                        IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Delete") }
                    }
                }
            )
        },
        bottomBar = {
            AnimatedVisibility(detail != null) {
                Surface(shadowElevation = 8.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(onClick = onReply, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Reply, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Reply")
                        }
                        Button(onClick = onForward, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Forward, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Forward")
                        }
                    }
                }
            }
        }
    ) { padding ->
        when {
            loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            detail == null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Unable to load this message")
            }
            else -> Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Text(detail.subject, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                detail.fromName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(detail.fromName.ifBlank { detail.fromAddress }, fontWeight = FontWeight.SemiBold)
                        Text(detail.fromAddress, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(detail.receivedAt)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(10.dp))
                Text("To: ${detail.to.joinToString()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (detail.cc.isNotEmpty()) {
                    Text("Cc: ${detail.cc.joinToString()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                if (detail.attachments.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    Text("Attachments", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    detail.attachments.forEach { attachment ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AttachFile, null)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(attachment.fileName, style = MaterialTheme.typography.bodyMedium)
                                    Text(attachment.mimeType, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(Modifier.padding(vertical = 20.dp))
                Text(detail.body.ifBlank { "(No message body)" }, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(30.dp))
            }
        }
    }
}
