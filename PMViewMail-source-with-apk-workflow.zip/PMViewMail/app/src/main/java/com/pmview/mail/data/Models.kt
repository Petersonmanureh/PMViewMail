package com.pmview.mail.data

import android.net.Uri

enum class MailFolder(val title: String) {
    INBOX("Inbox"),
    SENT("Sent"),
    DRAFTS("Drafts"),
    SPAM("Spam"),
    TRASH("Trash")
}

data class MailSummary(
    val uid: Long,
    val folder: MailFolder,
    val fromName: String,
    val fromAddress: String,
    val subject: String,
    val preview: String,
    val receivedAt: Long,
    val unread: Boolean,
    val starred: Boolean,
    val hasAttachments: Boolean
)

data class AttachmentInfo(
    val fileName: String,
    val mimeType: String,
    val size: Int = -1
)

data class MailDetail(
    val uid: Long,
    val folder: MailFolder,
    val fromName: String,
    val fromAddress: String,
    val to: List<String>,
    val cc: List<String>,
    val subject: String,
    val body: String,
    val receivedAt: Long,
    val unread: Boolean,
    val starred: Boolean,
    val attachments: List<AttachmentInfo>
)

data class OutgoingAttachment(
    val uri: Uri,
    val fileName: String,
    val mimeType: String
)

data class ComposeDraft(
    val to: String = "",
    val cc: String = "",
    val bcc: String = "",
    val subject: String = "",
    val body: String = "",
    val attachments: List<OutgoingAttachment> = emptyList()
)
