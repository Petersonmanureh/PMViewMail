# APK Build

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

It builds an installable debug APK and uploads it as the workflow artifact `PMView-Mail-APK`.

Output filename: `PMView-Mail-v1.0-debug.apk`.
