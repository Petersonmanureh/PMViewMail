# PMView Mail

PMView Mail is a native Android email client designed for Hostinger-hosted custom email accounts. The user only enters their full email address and password; Hostinger IMAP/SMTP settings are built into the app.

## Current build

This source project includes:

- Secure sign-in with full email address + password only
- Persistent login until the user explicitly logs out
- AES-256/GCM credential encryption backed by Android Keystore
- Hostinger IMAP inbox access over SSL (`imap.hostinger.com:993`)
- Hostinger SMTP sending over SSL (`smtp.hostinger.com:465`)
- Automatic SMTP fallback to STARTTLS on port `587`
- Inbox, Sent, Drafts, Spam/Junk and Trash folder navigation
- Read/unread handling
- Star/unstar messages
- Delete / move to Trash
- Compose, reply and forward
- CC and BCC expandable fields
- Multiple outgoing attachments
- Local mailbox search
- Pull-to-refresh and manual refresh
- New-mail Android notifications
- Background sync toggle
- Notification preview toggle
- 15 / 30 / 60 minute sync controls
- Notification tap opens the relevant message
- Dark mode toggle
- Material 3 UI, animated transitions and polished loading/error/empty states

## Technology

- Kotlin
- Jetpack Compose + Material 3
- Navigation Compose
- WorkManager
- Android Keystore
- JavaMail Android (`com.sun.mail:android-mail`)
- Minimum Android version: Android 7.0 / API 24
- Compile SDK: 37
- Target SDK: 36

## Build in Android Studio

1. Install Android Studio Rabbit 1 (2026.2.1) or newer.
2. Install Android SDK Platform 37 and Build Tools 36.0.0 if Android Studio requests them.
3. Open the `PMViewMail` folder as a project.
4. Allow Gradle to sync dependencies.
5. Select an Android phone/emulator and run the `app` configuration.
6. For an installable APK, use **Build > Build APK(s)**.
7. For Play Store deployment, configure a release signing key and generate an AAB from **Build > Generate Signed App Bundle or APK**.

The project declares Android Gradle Plugin 9.4.0 and Gradle 9.6.0 in its configuration. A Gradle wrapper properties file is included; if your IDE requests wrapper generation, let Android Studio generate the wrapper scripts/JAR once.

## Login behavior

The login screen intentionally contains only:

- Email address
- Password
- Show/hide password toggle
- Sign in button

On successful IMAP authentication, credentials are encrypted using an Android Keystore AES/GCM key. Closing or restarting the app does not log the user out. Logout wipes the encrypted session and cancels background mail checks.

## Hostinger settings built into the app

Incoming mail:

- Protocol: IMAP
- Host: `imap.hostinger.com`
- Port: `993`
- Encryption: SSL/TLS

Outgoing mail:

- Host: `smtp.hostinger.com`
- Primary port: `465`
- Encryption: SSL/TLS
- Fallback port: `587`
- Fallback encryption: STARTTLS

The full email address is used as the username.

## Notifications

The app uses Android WorkManager for reliable periodic background checks. The user can choose 15, 30 or 60 minutes. Android may slightly defer periodic work depending on battery optimization, Doze mode and manufacturer restrictions.

The app also refreshes immediately when opened or when the inbox is refreshed manually.

For truly near-instant Gmail-style push while the app is fully closed, a second production phase should add a small backend + Firebase Cloud Messaging (FCM) and, where applicable, Hostinger Mail webhooks/API. That avoids maintaining a permanent IMAP connection on the phone and is more compatible with modern Android background limits.

## Security notes

- Password is never stored in plain text.
- Credentials stay on the user's Android device in this version.
- Cloud backups exclude the app's shared preferences.
- Network traffic uses TLS.
- Cleartext HTTP traffic is disabled in the Android manifest.
- No analytics or advertising SDK is included.

## Project structure

```text
app/src/main/java/com/pmview/mail/
├── MainActivity.kt
├── PMViewMailApp.kt
├── AppGraph.kt
├── data/
│   ├── AppSettings.kt
│   ├── CredentialVault.kt
│   └── Models.kt
├── mail/
│   └── MailRepository.kt
├── notifications/
│   ├── MailSyncWorker.kt
│   ├── NotificationHelper.kt
│   └── SyncScheduler.kt
└── ui/
    ├── MailViewModel.kt
    ├── screens/
    │   ├── LoginScreen.kt
    │   ├── MailboxScreen.kt
    │   ├── MessageScreen.kt
    │   ├── ComposeScreen.kt
    │   └── SettingsScreen.kt
    └── theme/
        └── Theme.kt
```

## Production enhancements recommended next

1. Download/save incoming attachments.
2. HTML email rendering with safe remote-image controls.
3. Draft auto-save to the IMAP Drafts folder.
4. Archive and move-to-folder actions.
5. Multiple account support.
6. Contact suggestions and autocomplete.
7. Conversation/thread view.
8. FCM near-instant push notification backend.
9. Biometric app lock.
10. Custom PMView Mail logo, splash screen and Play Store assets.

## Working name

The package name is `com.pmview.mail` and the current app name is **PMView Mail**. Both can be changed before release.
