package com.pmview.mail.data

import android.content.Context

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("pmview_mail_settings", Context.MODE_PRIVATE)

    var backgroundNotifications: Boolean
        get() = prefs.getBoolean("background_notifications", true)
        set(value) = prefs.edit().putBoolean("background_notifications", value).apply()

    var notificationPreview: Boolean
        get() = prefs.getBoolean("notification_preview", true)
        set(value) = prefs.edit().putBoolean("notification_preview", value).apply()

    var darkMode: Boolean
        get() = prefs.getBoolean("dark_mode", false)
        set(value) = prefs.edit().putBoolean("dark_mode", value).apply()

    var syncMinutes: Long
        get() = prefs.getLong("sync_minutes", 15L).coerceAtLeast(15L)
        set(value) = prefs.edit().putLong("sync_minutes", value.coerceAtLeast(15L)).apply()

    var senderName: String
        get() = prefs.getString("sender_name", "").orEmpty()
        set(value) = prefs.edit().putString("sender_name", value.trim()).apply()

    var lastInboxUid: Long
        get() = prefs.getLong("last_inbox_uid", 0L)
        set(value) = prefs.edit().putLong("last_inbox_uid", value).apply()
}
