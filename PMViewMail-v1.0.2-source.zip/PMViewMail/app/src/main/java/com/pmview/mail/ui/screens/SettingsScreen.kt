package com.pmview.mail.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    accountEmail: String,
    darkMode: Boolean,
    backgroundNotifications: Boolean,
    notificationPreview: Boolean,
    syncMinutes: Long,
    senderName: String,
    onBack: () -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onBackgroundNotifications: (Boolean) -> Unit,
    onNotificationPreview: (Boolean) -> Unit,
    onSyncMinutes: (Long) -> Unit,
    onSenderName: (String) -> Unit,
    onLogout: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.AccountCircle, null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Signed in", style = MaterialTheme.typography.labelMedium)
                        Text(accountEmail, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Badge, null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Sender name", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Recipients see this name instead of your email address.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = senderName,
                        onValueChange = onSenderName,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Display name") },
                        placeholder = { Text("e.g. Peterson Manureh") },
                        supportingText = {
                            Text(if (senderName.isBlank()) "If left blank, your email address will be shown." else "Outgoing mail will display: ${senderName.trim()}")
                        }
                    )
                }
            }

            SettingsSwitch(
                icon = { Icon(Icons.Outlined.DarkMode, null) },
                title = "Dark theme",
                subtitle = "Use the darker professional interface",
                checked = darkMode,
                onChecked = onDarkMode
            )

            SettingsSwitch(
                icon = { Icon(Icons.Outlined.NotificationsActive, null) },
                title = "Background notifications",
                subtitle = "Check for new mail even after the app is closed",
                checked = backgroundNotifications,
                onChecked = onBackgroundNotifications
            )

            AnimatedVisibility(backgroundNotifications) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingsSwitch(
                        icon = { Icon(Icons.Outlined.Visibility, null) },
                        title = "Show message preview",
                        subtitle = "Include the subject and preview in notifications",
                        checked = notificationPreview,
                        onChecked = onNotificationPreview
                    )

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Sync, null)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Sync frequency", fontWeight = FontWeight.SemiBold)
                                    Text("How often to check in the background", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(15L, 30L, 60L).forEach { minutes ->
                                    FilterChip(
                                        selected = syncMinutes == minutes,
                                        onClick = { onSyncMinutes(minutes) },
                                        label = { Text(if (minutes == 60L) "1 hour" else "$minutes min") }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Mail server", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Hostinger Mail", style = MaterialTheme.typography.bodyMedium)
                    Text("Secure IMAP/SMTP settings are managed automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Outlined.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Logout")
            }
        }
    }
}

@Composable
private fun SettingsSwitch(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}
