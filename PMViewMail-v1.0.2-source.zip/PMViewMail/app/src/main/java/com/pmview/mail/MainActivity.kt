package com.pmview.mail

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pmview.mail.data.MailFolder
import com.pmview.mail.ui.MailViewModel
import com.pmview.mail.ui.screens.*
import com.pmview.mail.ui.theme.PMViewMailTheme

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_FOLDER = "open_folder"
        const val EXTRA_UID = "open_uid"
    }

    private data class PendingOpen(val folder: MailFolder, val uid: Long)
    private val pendingOpen = mutableStateOf<PendingOpen?>(null)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        parseIntent(intent)
        requestNotificationPermissionIfNeeded()

        setContent {
            val app = application as PMViewMailApp
            val vm: MailViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MailViewModel(app.graph) as T
                }
            })

            val darkMode by vm.darkMode.collectAsState()
            PMViewMailTheme(darkTheme = darkMode) {
                PMViewMailRoot(
                    vm = vm,
                    pendingOpen = pendingOpen.value,
                    consumePending = { pendingOpen.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parseIntent(intent)
    }

    private fun parseIntent(intent: Intent?) {
        val folderName = intent?.getStringExtra(EXTRA_FOLDER) ?: return
        val uid = intent.getLongExtra(EXTRA_UID, -1L)
        val folder = runCatching { MailFolder.valueOf(folderName) }.getOrNull() ?: return
        if (uid > 0) pendingOpen.value = PendingOpen(folder, uid)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    @Composable
    private fun PMViewMailRoot(
        vm: MailViewModel,
        pendingOpen: PendingOpen?,
        consumePending: () -> Unit
    ) {
        val loggedIn by vm.loggedIn.collectAsState()
        val loginLoading by vm.loginLoading.collectAsState()
        val loginError by vm.loginError.collectAsState()

        if (!loggedIn) {
            LoginScreen(
                loading = loginLoading,
                error = loginError,
                onLogin = vm::login
            )
            return
        }

        val navController = rememberNavController()

        LaunchedEffect(loggedIn) {
            if (loggedIn && vm.messages.value.isEmpty()) vm.refresh()
        }

        LaunchedEffect(pendingOpen) {
            pendingOpen?.let {
                navController.navigate("message/${it.folder.name}/${it.uid}")
                consumePending()
            }
        }

        NavHost(navController = navController, startDestination = "mailbox") {
            composable("mailbox") {
                val folder by vm.folder.collectAsState()
                val messages by vm.messages.collectAsState()
                val loading by vm.loading.collectAsState()
                val error by vm.mailError.collectAsState()
                val query by vm.query.collectAsState()

                MailboxScreen(
                    accountEmail = vm.accountEmail(),
                    folder = folder,
                    messages = messages,
                    loading = loading,
                    error = error,
                    query = query,
                    onFolder = vm::selectFolder,
                    onRefresh = vm::refresh,
                    onSearch = vm::search,
                    onOpen = { mail -> navController.navigate("message/${mail.folder.name}/${mail.uid}") },
                    onToggleStar = { mail, starred -> vm.toggleStar(mail.folder, mail.uid, starred) },
                    onCompose = {
                        vm.newDraft()
                        navController.navigate("compose")
                    },
                    onSettings = { navController.navigate("settings") },
                    onLogout = vm::logout
                )
            }

            composable(
                route = "message/{folder}/{uid}",
                arguments = listOf(
                    navArgument("folder") { type = NavType.StringType },
                    navArgument("uid") { type = NavType.LongType }
                )
            ) { backStack ->
                val folder = runCatching {
                    MailFolder.valueOf(backStack.arguments?.getString("folder") ?: MailFolder.INBOX.name)
                }.getOrDefault(MailFolder.INBOX)
                val uid = backStack.arguments?.getLong("uid") ?: -1L
                val detail by vm.detail.collectAsState()
                val loading by vm.detailLoading.collectAsState()

                LaunchedEffect(folder, uid) { if (uid > 0) vm.openMessage(folder, uid) }

                MessageScreen(
                    detail = detail,
                    loading = loading,
                    onBack = { navController.popBackStack() },
                    onStar = { vm.toggleStar(folder, uid, it) },
                    onDelete = { vm.delete(folder, uid) { navController.popBackStack() } },
                    onReply = {
                        detail?.let(vm::reply)
                        navController.navigate("compose")
                    },
                    onForward = {
                        detail?.let(vm::forward)
                        navController.navigate("compose")
                    }
                )
            }

            composable("compose") {
                val draft by vm.draft.collectAsState()
                val sending by vm.sending.collectAsState()
                val status by vm.sendStatus.collectAsState()
                ComposeScreen(
                    draft = draft,
                    sending = sending,
                    status = status,
                    onChange = vm::updateDraft,
                    onSend = {
                        vm.send {
                            Toast.makeText(this@MainActivity, "Message sent", Toast.LENGTH_SHORT).show()
                            navController.popBackStack()
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable("settings") {
                val dark by vm.darkMode.collectAsState()
                val notifications by vm.backgroundNotifications.collectAsState()
                val preview by vm.notificationPreview.collectAsState()
                val frequency by vm.syncMinutes.collectAsState()
                val senderName by vm.senderName.collectAsState()
                SettingsScreen(
                    accountEmail = vm.accountEmail(),
                    darkMode = dark,
                    backgroundNotifications = notifications,
                    notificationPreview = preview,
                    syncMinutes = frequency,
                    senderName = senderName,
                    onBack = { navController.popBackStack() },
                    onDarkMode = vm::setDarkMode,
                    onBackgroundNotifications = vm::setBackgroundNotifications,
                    onNotificationPreview = vm::setNotificationPreview,
                    onSyncMinutes = vm::setSyncMinutes,
                    onSenderName = vm::setSenderName,
                    onLogout = vm::logout
                )
            }
        }
    }
}
